import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.cluster.hierarchy import dendrogram, linkage, fcluster, maxdists
from sklearn.preprocessing import StandardScaler, LabelEncoder

# Завантаження датасету
df = pd.read_excel("data_lab3.xlsx")

# Вибираємо корисні стовпці для кластеризації
columns_to_use = ["мітка", "Like", "Поширення", "Джерело"]
df = df.dropna(subset=columns_to_use)  # Видаляємо порожні значення

# Конвертуємо числові колонки, якщо є помилки, замінюємо їх на NaN
df["Like"] = pd.to_numeric(df["Like"], errors="coerce")
df["Поширення"] = pd.to_numeric(df["Поширення"], errors="coerce")
df["мітка"] = pd.to_numeric(df["мітка"], errors="coerce")

# Видаляємо рядки, які містять NaN після конвертації
df = df.dropna(subset=["Like", "Поширення", "мітка"])

# Перетворення текстових даних у числові
df["Джерело"] = df["Джерело"].astype(str)
label_encoder = LabelEncoder()
df["Джерело"] = label_encoder.fit_transform(df["Джерело"])

# Масштабування даних
scaler = StandardScaler()
data_scaled = scaler.fit_transform(df[columns_to_use])

# Вибираємо підмножину для коректної візуалізації
df_sample = df.iloc[:100]  # Беремо лише перші 100 записів
data_scaled_sample = data_scaled[:100]

# Виконуємо ієрархічну кластеризацію
linkage_matrix = linkage(data_scaled_sample, method="ward")

# Візуалізація дендрограми без зайвих підписів
plt.figure(figsize=(12, 6))
dendrogram(linkage_matrix, no_labels=True, leaf_rotation=90, leaf_font_size=8)
plt.title("Дендрограма ієрархічної кластеризації")
plt.xlabel("Новини")
plt.ylabel("Відстань")
plt.show()

# Визначаємо оптимальну кількість кластерів
threshold_value = maxdists(linkage_matrix)[-1]  # Використовуємо останній

df_sample["Cluster"] = fcluster(linkage_matrix, threshold_value,
                                criterion="distance")

# Візуалізація розподілу кластерів
sns.scatterplot(x=df_sample["Like"], y=df_sample["Поширення"],
                hue=df_sample["Cluster"], palette="viridis", s=100,
                edgecolor="k")
plt.title("Кластеризація новин за лайками та поширеннями")
plt.xlabel("Кількість лайків")
plt.ylabel("Кількість поширень")
plt.show()

